exports.MyJSONController = function (req, res, next) {
    // Use the ISML class to render a template.
    var template = 'clientrender';
    
    return next();
    // The template should be passed the header data from your function and print it as JSON.
};
exports.MyJSONController.public = true;
 