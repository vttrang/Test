exports.MyJSONController = function (req, res, next) {
    // Use the ISML class to render a template.
    // var template = 'renderJSONTest';
    var tempData = {
        firstName: 'Vinh',
        lastName: 'Trang'
    };
    // res.render(template, {
    //     data: tempData
    // });
    res.json({
        data: tempData
    });
    return next();
    // The template should be passed the header data from your function and print it as JSON.
};
exports.MyJSONController.public = true;
 