'use strict';

var server = require('server');

server.get('ClientRednerController', function (req, res, next) {
    var template = 'common/clientrender';
    res.render(template);
    return next();
});

module.exports = server.exports();
