'use strict';

var server = require('server');

server.get('MyJSONController', function (req, res, next) {
    // Use the ISML class to render a template.
    // var template = 'renderJSONTest';
    var tempData = {
        firstName: 'Vinh',
        lastName: 'Trang'
    };
    // res.render(template, {
    //     data: tempData
    // });
    res.json({
        data: tempData
    });
    return next();
});

module.exports = server.exports();
