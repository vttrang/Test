'use strict';

// This will capture hash changes while on the page
$(window).on('load', function () {
    const URL = 'https://dev07-na03-hbc.demandware.net/on/demandware.store/Sites-SaksOff5th-Site/default/SFCC-MyJSONController';
    $.ajax({
        url: URL,
        method: 'GET',
        dataType: 'json',
        success: function (response) {
            const data = JSON.stringify(response);
            const $result = $('.render-result');
            if ($result && $result.length > 0) {
                $result.html(data);
            } else {
                $("body").innerText = data;
            }
        },
        error: function () {
            console('Error at SFFC.js');
        }
    });
});
